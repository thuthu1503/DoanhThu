﻿namespace QLBtivi
{
    public partial class Form3
    {

       
    }
}