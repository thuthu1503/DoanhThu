﻿namespace QLBtivi
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tDSSP = new System.Windows.Forms.TabPage();
            this.btnLuuSP = new System.Windows.Forms.Button();
            this.btnXoaSP = new System.Windows.Forms.Button();
            this.btnThoatSP = new System.Windows.Forms.Button();
            this.btnHuySP = new System.Windows.Forms.Button();
            this.btnSuaSP = new System.Windows.Forms.Button();
            this.btnTimKiemSP = new System.Windows.Forms.Button();
            this.btnThemSP = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.dtgDSSP = new System.Windows.Forms.DataGridView();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.txtTGBH = new System.Windows.Forms.TextBox();
            this.txtDonGiaBan = new System.Windows.Forms.TextBox();
            this.txtDonGiaNhap = new System.Windows.Forms.TextBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.txtMaNuocSX = new System.Windows.Forms.TextBox();
            this.txtMaCo = new System.Windows.Forms.TextBox();
            this.txtMaManHinh = new System.Windows.Forms.TextBox();
            this.txtMaMau = new System.Windows.Forms.TextBox();
            this.txtMaKieu = new System.Windows.Forms.TextBox();
            this.txtMaHSX = new System.Windows.Forms.TextBox();
            this.txtTenTV = new System.Windows.Forms.TextBox();
            this.txtMaTV = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.tNhanVien = new System.Windows.Forms.TabPage();
            this.btnThoatNV = new System.Windows.Forms.Button();
            this.btnHuyNV = new System.Windows.Forms.Button();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.btnTimKiemNV = new System.Windows.Forms.Button();
            this.btnSuaNV = new System.Windows.Forms.Button();
            this.btnLuuNV = new System.Windows.Forms.Button();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.dgvDSNV = new System.Windows.Forms.DataGridView();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtMaCV = new System.Windows.Forms.TextBox();
            this.txtMaCa = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.txtGioiTinh = new System.Windows.Forms.TextBox();
            this.txtTenNV = new System.Windows.Forms.TextBox();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.tBanHang = new System.Windows.Forms.TabPage();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtTTB = new System.Windows.Forms.TextBox();
            this.txtGG = new System.Windows.Forms.TextBox();
            this.nudSLB = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtDGB = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.txtMaTVB = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtMaNVB = new System.Windows.Forms.TextBox();
            this.txtSoHDB = new System.Windows.Forms.TextBox();
            this.txtMaKH = new System.Windows.Forms.TextBox();
            this.txtThue = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tNhapHang = new System.Windows.Forms.TabPage();
            this.btnSua = new System.Windows.Forms.Button();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvDSNhap = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtThanhTien = new System.Windows.Forms.TextBox();
            this.txtGiamGia = new System.Windows.Forms.TextBox();
            this.nudSLN = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.txtMaTVN = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtSoHDN = new System.Windows.Forms.TextBox();
            this.txtMaNVN = new System.Windows.Forms.TextBox();
            this.txtMaNCC = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.QuanLiBanTV = new System.Windows.Forms.TabControl();
            this.tDoanhThu = new System.Windows.Forms.TabPage();
            this.btnLuuDT = new System.Windows.Forms.Button();
            this.btnThoatDT = new System.Windows.Forms.Button();
            this.btnTimKiemDT = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.dgvDoanhThu = new System.Windows.Forms.DataGridView();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.txtNgaySinh = new System.Windows.Forms.MaskedTextBox();
            this.txtNgayBan = new System.Windows.Forms.MaskedTextBox();
            this.txtNgayNhap = new System.Windows.Forms.MaskedTextBox();
            this.txtFrom = new System.Windows.Forms.MaskedTextBox();
            this.txtTo = new System.Windows.Forms.MaskedTextBox();
            this.tDSSP.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgDSSP)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.tNhanVien.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSNV)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.tBanHang.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSLB)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.tNhapHang.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSNhap)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSLN)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.QuanLiBanTV.SuspendLayout();
            this.tDoanhThu.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoanhThu)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.SuspendLayout();
            // 
            // tDSSP
            // 
            this.tDSSP.Controls.Add(this.btnLuuSP);
            this.tDSSP.Controls.Add(this.btnXoaSP);
            this.tDSSP.Controls.Add(this.btnThoatSP);
            this.tDSSP.Controls.Add(this.btnHuySP);
            this.tDSSP.Controls.Add(this.btnSuaSP);
            this.tDSSP.Controls.Add(this.btnTimKiemSP);
            this.tDSSP.Controls.Add(this.btnThemSP);
            this.tDSSP.Controls.Add(this.groupBox10);
            this.tDSSP.Controls.Add(this.groupBox9);
            this.tDSSP.Location = new System.Drawing.Point(4, 25);
            this.tDSSP.Name = "tDSSP";
            this.tDSSP.Size = new System.Drawing.Size(1134, 544);
            this.tDSSP.TabIndex = 3;
            this.tDSSP.Text = "Danh sách sản phẩm";
            this.tDSSP.UseVisualStyleBackColor = true;
            this.tDSSP.Click += new System.EventHandler(this.tDSSP_Click);
            // 
            // btnLuuSP
            // 
            this.btnLuuSP.Location = new System.Drawing.Point(945, 365);
            this.btnLuuSP.Name = "btnLuuSP";
            this.btnLuuSP.Size = new System.Drawing.Size(161, 51);
            this.btnLuuSP.TabIndex = 3;
            this.btnLuuSP.Text = "Lưu";
            this.btnLuuSP.UseVisualStyleBackColor = true;
            // 
            // btnXoaSP
            // 
            this.btnXoaSP.Location = new System.Drawing.Point(756, 365);
            this.btnXoaSP.Name = "btnXoaSP";
            this.btnXoaSP.Size = new System.Drawing.Size(161, 51);
            this.btnXoaSP.TabIndex = 4;
            this.btnXoaSP.Text = "Xóa";
            this.btnXoaSP.UseVisualStyleBackColor = true;
            // 
            // btnThoatSP
            // 
            this.btnThoatSP.Location = new System.Drawing.Point(860, 434);
            this.btnThoatSP.Name = "btnThoatSP";
            this.btnThoatSP.Size = new System.Drawing.Size(161, 51);
            this.btnThoatSP.TabIndex = 5;
            this.btnThoatSP.Text = "Thoát";
            this.btnThoatSP.UseVisualStyleBackColor = true;
            // 
            // btnHuySP
            // 
            this.btnHuySP.Location = new System.Drawing.Point(670, 434);
            this.btnHuySP.Name = "btnHuySP";
            this.btnHuySP.Size = new System.Drawing.Size(161, 51);
            this.btnHuySP.TabIndex = 5;
            this.btnHuySP.Text = "Hủy";
            this.btnHuySP.UseVisualStyleBackColor = true;
            // 
            // btnSuaSP
            // 
            this.btnSuaSP.Location = new System.Drawing.Point(569, 365);
            this.btnSuaSP.Name = "btnSuaSP";
            this.btnSuaSP.Size = new System.Drawing.Size(161, 51);
            this.btnSuaSP.TabIndex = 6;
            this.btnSuaSP.Text = "Sửa";
            this.btnSuaSP.UseVisualStyleBackColor = true;
            this.btnSuaSP.Click += new System.EventHandler(this.btnSuaSP_Click);
            // 
            // btnTimKiemSP
            // 
            this.btnTimKiemSP.Location = new System.Drawing.Point(465, 434);
            this.btnTimKiemSP.Name = "btnTimKiemSP";
            this.btnTimKiemSP.Size = new System.Drawing.Size(161, 51);
            this.btnTimKiemSP.TabIndex = 7;
            this.btnTimKiemSP.Text = "Tìm kiếm";
            this.btnTimKiemSP.UseVisualStyleBackColor = true;
            // 
            // btnThemSP
            // 
            this.btnThemSP.Location = new System.Drawing.Point(390, 365);
            this.btnThemSP.Name = "btnThemSP";
            this.btnThemSP.Size = new System.Drawing.Size(161, 51);
            this.btnThemSP.TabIndex = 8;
            this.btnThemSP.Text = "Thêm";
            this.btnThemSP.UseVisualStyleBackColor = true;
            this.btnThemSP.Click += new System.EventHandler(this.btnThemSP_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.dtgDSSP);
            this.groupBox10.Location = new System.Drawing.Point(387, 0);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(744, 329);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Thông tin sản phấm";
            // 
            // dtgDSSP
            // 
            this.dtgDSSP.BackgroundColor = System.Drawing.Color.LightCyan;
            this.dtgDSSP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgDSSP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtgDSSP.Location = new System.Drawing.Point(3, 18);
            this.dtgDSSP.Name = "dtgDSSP";
            this.dtgDSSP.RowHeadersWidth = 51;
            this.dtgDSSP.RowTemplate.Height = 24;
            this.dtgDSSP.Size = new System.Drawing.Size(738, 308);
            this.dtgDSSP.TabIndex = 0;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.txtTGBH);
            this.groupBox9.Controls.Add(this.txtDonGiaBan);
            this.groupBox9.Controls.Add(this.txtDonGiaNhap);
            this.groupBox9.Controls.Add(this.txtSoLuong);
            this.groupBox9.Controls.Add(this.txtMaNuocSX);
            this.groupBox9.Controls.Add(this.txtMaCo);
            this.groupBox9.Controls.Add(this.txtMaManHinh);
            this.groupBox9.Controls.Add(this.txtMaMau);
            this.groupBox9.Controls.Add(this.txtMaKieu);
            this.groupBox9.Controls.Add(this.txtMaHSX);
            this.groupBox9.Controls.Add(this.txtTenTV);
            this.groupBox9.Controls.Add(this.txtMaTV);
            this.groupBox9.Controls.Add(this.label43);
            this.groupBox9.Controls.Add(this.label42);
            this.groupBox9.Controls.Add(this.label41);
            this.groupBox9.Controls.Add(this.label40);
            this.groupBox9.Controls.Add(this.label39);
            this.groupBox9.Controls.Add(this.label38);
            this.groupBox9.Controls.Add(this.label37);
            this.groupBox9.Controls.Add(this.label36);
            this.groupBox9.Controls.Add(this.label35);
            this.groupBox9.Controls.Add(this.label34);
            this.groupBox9.Controls.Add(this.label33);
            this.groupBox9.Controls.Add(this.label32);
            this.groupBox9.Controls.Add(this.label31);
            this.groupBox9.Location = new System.Drawing.Point(3, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(378, 533);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Nhập thông tin sản phẩm";
            // 
            // txtTGBH
            // 
            this.txtTGBH.Location = new System.Drawing.Point(141, 505);
            this.txtTGBH.Name = "txtTGBH";
            this.txtTGBH.Size = new System.Drawing.Size(106, 22);
            this.txtTGBH.TabIndex = 1;
            // 
            // txtDonGiaBan
            // 
            this.txtDonGiaBan.Location = new System.Drawing.Point(141, 431);
            this.txtDonGiaBan.Name = "txtDonGiaBan";
            this.txtDonGiaBan.Size = new System.Drawing.Size(106, 22);
            this.txtDonGiaBan.TabIndex = 1;
            // 
            // txtDonGiaNhap
            // 
            this.txtDonGiaNhap.Location = new System.Drawing.Point(141, 391);
            this.txtDonGiaNhap.Name = "txtDonGiaNhap";
            this.txtDonGiaNhap.Size = new System.Drawing.Size(106, 22);
            this.txtDonGiaNhap.TabIndex = 1;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(141, 347);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(106, 22);
            this.txtSoLuong.TabIndex = 1;
            // 
            // txtMaNuocSX
            // 
            this.txtMaNuocSX.Location = new System.Drawing.Point(141, 304);
            this.txtMaNuocSX.Name = "txtMaNuocSX";
            this.txtMaNuocSX.Size = new System.Drawing.Size(106, 22);
            this.txtMaNuocSX.TabIndex = 1;
            // 
            // txtMaCo
            // 
            this.txtMaCo.Location = new System.Drawing.Point(141, 261);
            this.txtMaCo.Name = "txtMaCo";
            this.txtMaCo.Size = new System.Drawing.Size(106, 22);
            this.txtMaCo.TabIndex = 1;
            // 
            // txtMaManHinh
            // 
            this.txtMaManHinh.Location = new System.Drawing.Point(141, 217);
            this.txtMaManHinh.Name = "txtMaManHinh";
            this.txtMaManHinh.Size = new System.Drawing.Size(106, 22);
            this.txtMaManHinh.TabIndex = 1;
            // 
            // txtMaMau
            // 
            this.txtMaMau.Location = new System.Drawing.Point(141, 176);
            this.txtMaMau.Name = "txtMaMau";
            this.txtMaMau.Size = new System.Drawing.Size(106, 22);
            this.txtMaMau.TabIndex = 1;
            // 
            // txtMaKieu
            // 
            this.txtMaKieu.Location = new System.Drawing.Point(141, 134);
            this.txtMaKieu.Name = "txtMaKieu";
            this.txtMaKieu.Size = new System.Drawing.Size(106, 22);
            this.txtMaKieu.TabIndex = 1;
            // 
            // txtMaHSX
            // 
            this.txtMaHSX.Location = new System.Drawing.Point(141, 90);
            this.txtMaHSX.Name = "txtMaHSX";
            this.txtMaHSX.Size = new System.Drawing.Size(100, 22);
            this.txtMaHSX.TabIndex = 1;
            // 
            // txtTenTV
            // 
            this.txtTenTV.Location = new System.Drawing.Point(141, 48);
            this.txtTenTV.Name = "txtTenTV";
            this.txtTenTV.Size = new System.Drawing.Size(100, 22);
            this.txtTenTV.TabIndex = 1;
            // 
            // txtMaTV
            // 
            this.txtMaTV.Location = new System.Drawing.Point(141, 15);
            this.txtMaTV.Name = "txtMaTV";
            this.txtMaTV.Size = new System.Drawing.Size(100, 22);
            this.txtMaTV.TabIndex = 1;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(9, 505);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(125, 16);
            this.label43.TabIndex = 0;
            this.label43.Text = "Thời gian bảo hành:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(11, 466);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(33, 16);
            this.label42.TabIndex = 0;
            this.label42.Text = "Ảnh:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(11, 431);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(82, 16);
            this.label41.TabIndex = 0;
            this.label41.Text = "Đơn giá bán:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(9, 347);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(63, 16);
            this.label40.TabIndex = 0;
            this.label40.Text = "Số lượng:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(11, 397);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(89, 16);
            this.label39.TabIndex = 0;
            this.label39.Text = "Đơn giá nhập:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(9, 310);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(77, 16);
            this.label38.TabIndex = 0;
            this.label38.Text = "Mã nước sx:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(9, 264);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(47, 16);
            this.label37.TabIndex = 0;
            this.label37.Text = "Mã cỡ:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(9, 220);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(85, 16);
            this.label36.TabIndex = 0;
            this.label36.Text = "Mã màn hình:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(9, 182);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 16);
            this.label35.TabIndex = 0;
            this.label35.Text = "Mã  màu:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(9, 140);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(57, 16);
            this.label34.TabIndex = 0;
            this.label34.Text = "Mã kiểu:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(9, 96);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(114, 16);
            this.label33.TabIndex = 0;
            this.label33.Text = "Mã hãng sản xuất:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(9, 54);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(53, 16);
            this.label32.TabIndex = 0;
            this.label32.Text = "Tên tivi:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(9, 21);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(48, 16);
            this.label31.TabIndex = 0;
            this.label31.Text = "Mã tivi:";
            // 
            // tNhanVien
            // 
            this.tNhanVien.Controls.Add(this.btnThoatNV);
            this.tNhanVien.Controls.Add(this.btnHuyNV);
            this.tNhanVien.Controls.Add(this.btnXoaNV);
            this.tNhanVien.Controls.Add(this.btnTimKiemNV);
            this.tNhanVien.Controls.Add(this.btnSuaNV);
            this.tNhanVien.Controls.Add(this.btnLuuNV);
            this.tNhanVien.Controls.Add(this.btnThemNV);
            this.tNhanVien.Controls.Add(this.groupBox8);
            this.tNhanVien.Controls.Add(this.groupBox7);
            this.tNhanVien.Location = new System.Drawing.Point(4, 25);
            this.tNhanVien.Name = "tNhanVien";
            this.tNhanVien.Size = new System.Drawing.Size(1134, 544);
            this.tNhanVien.TabIndex = 2;
            this.tNhanVien.Text = "Nhân viên";
            this.tNhanVien.UseVisualStyleBackColor = true;
            // 
            // btnThoatNV
            // 
            this.btnThoatNV.Location = new System.Drawing.Point(901, 445);
            this.btnThoatNV.Name = "btnThoatNV";
            this.btnThoatNV.Size = new System.Drawing.Size(93, 37);
            this.btnThoatNV.TabIndex = 2;
            this.btnThoatNV.Text = "Thoát";
            this.btnThoatNV.UseVisualStyleBackColor = true;
            // 
            // btnHuyNV
            // 
            this.btnHuyNV.Location = new System.Drawing.Point(721, 445);
            this.btnHuyNV.Name = "btnHuyNV";
            this.btnHuyNV.Size = new System.Drawing.Size(103, 37);
            this.btnHuyNV.TabIndex = 2;
            this.btnHuyNV.Text = "Hủy";
            this.btnHuyNV.UseVisualStyleBackColor = true;
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.Location = new System.Drawing.Point(807, 383);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(99, 37);
            this.btnXoaNV.TabIndex = 2;
            this.btnXoaNV.Text = "Xóa";
            this.btnXoaNV.UseVisualStyleBackColor = true;
            // 
            // btnTimKiemNV
            // 
            this.btnTimKiemNV.Location = new System.Drawing.Point(542, 445);
            this.btnTimKiemNV.Name = "btnTimKiemNV";
            this.btnTimKiemNV.Size = new System.Drawing.Size(102, 37);
            this.btnTimKiemNV.TabIndex = 2;
            this.btnTimKiemNV.Text = "Tìm  kiếm";
            this.btnTimKiemNV.UseVisualStyleBackColor = true;
            // 
            // btnSuaNV
            // 
            this.btnSuaNV.Location = new System.Drawing.Point(634, 383);
            this.btnSuaNV.Name = "btnSuaNV";
            this.btnSuaNV.Size = new System.Drawing.Size(103, 37);
            this.btnSuaNV.TabIndex = 2;
            this.btnSuaNV.Text = "Sửa";
            this.btnSuaNV.UseVisualStyleBackColor = true;
            // 
            // btnLuuNV
            // 
            this.btnLuuNV.Location = new System.Drawing.Point(971, 383);
            this.btnLuuNV.Name = "btnLuuNV";
            this.btnLuuNV.Size = new System.Drawing.Size(97, 37);
            this.btnLuuNV.TabIndex = 2;
            this.btnLuuNV.Text = "Lưu";
            this.btnLuuNV.UseVisualStyleBackColor = true;
            // 
            // btnThemNV
            // 
            this.btnThemNV.Location = new System.Drawing.Point(471, 383);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(98, 37);
            this.btnThemNV.TabIndex = 2;
            this.btnThemNV.Text = "Thêm";
            this.btnThemNV.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.dgvDSNV);
            this.groupBox8.Location = new System.Drawing.Point(434, 14);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(692, 344);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Thông tin nhân viên";
            // 
            // dgvDSNV
            // 
            this.dgvDSNV.BackgroundColor = System.Drawing.Color.LightCyan;
            this.dgvDSNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSNV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDSNV.Location = new System.Drawing.Point(3, 18);
            this.dgvDSNV.Name = "dgvDSNV";
            this.dgvDSNV.RowHeadersWidth = 51;
            this.dgvDSNV.RowTemplate.Height = 24;
            this.dgvDSNV.Size = new System.Drawing.Size(686, 323);
            this.dgvDSNV.TabIndex = 0;
          
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtNgaySinh);
            this.groupBox7.Controls.Add(this.txtMaCV);
            this.groupBox7.Controls.Add(this.txtMaCa);
            this.groupBox7.Controls.Add(this.txtDiaChi);
            this.groupBox7.Controls.Add(this.txtDienThoai);
            this.groupBox7.Controls.Add(this.txtGioiTinh);
            this.groupBox7.Controls.Add(this.txtTenNV);
            this.groupBox7.Controls.Add(this.txtMaNV);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Controls.Add(this.label25);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Location = new System.Drawing.Point(8, 14);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(420, 512);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Nhập thông tin nhân viên";
            // 
            // txtMaCV
            // 
            this.txtMaCV.Location = new System.Drawing.Point(135, 446);
            this.txtMaCV.Name = "txtMaCV";
            this.txtMaCV.Size = new System.Drawing.Size(100, 22);
            this.txtMaCV.TabIndex = 1;
            // 
            // txtMaCa
            // 
            this.txtMaCa.Location = new System.Drawing.Point(135, 390);
            this.txtMaCa.Name = "txtMaCa";
            this.txtMaCa.Size = new System.Drawing.Size(100, 22);
            this.txtMaCa.TabIndex = 1;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(135, 339);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(100, 22);
            this.txtDiaChi.TabIndex = 1;
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Location = new System.Drawing.Point(135, 276);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(100, 22);
            this.txtDienThoai.TabIndex = 1;
            // 
            // txtGioiTinh
            // 
            this.txtGioiTinh.Location = new System.Drawing.Point(135, 152);
            this.txtGioiTinh.Name = "txtGioiTinh";
            this.txtGioiTinh.Size = new System.Drawing.Size(100, 22);
            this.txtGioiTinh.TabIndex = 1;
            // 
            // txtTenNV
            // 
            this.txtTenNV.Location = new System.Drawing.Point(135, 90);
            this.txtTenNV.Name = "txtTenNV";
            this.txtTenNV.Size = new System.Drawing.Size(100, 22);
            this.txtTenNV.TabIndex = 1;
            // 
            // txtMaNV
            // 
            this.txtMaNV.Location = new System.Drawing.Point(135, 22);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.Size = new System.Drawing.Size(100, 22);
            this.txtMaNV.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(7, 452);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(46, 16);
            this.label30.TabIndex = 0;
            this.label30.Text = "Mã cv:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(7, 390);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(47, 16);
            this.label29.TabIndex = 0;
            this.label29.Text = "Mã ca:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(7, 345);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(50, 16);
            this.label28.TabIndex = 0;
            this.label28.Text = "Địa chỉ:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(7, 279);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(69, 16);
            this.label27.TabIndex = 0;
            this.label27.Text = "Điện thoại:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(7, 214);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(70, 16);
            this.label26.TabIndex = 0;
            this.label26.Text = "Ngày sinh:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(7, 158);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(57, 16);
            this.label25.TabIndex = 0;
            this.label25.Text = "Giới tính:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(7, 93);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(94, 16);
            this.label24.TabIndex = 0;
            this.label24.Text = "Tên nhân viên:";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(7, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(89, 16);
            this.label18.TabIndex = 0;
            this.label18.Text = "Mã nhân viên:";
            // 
            // tBanHang
            // 
            this.tBanHang.BackColor = System.Drawing.Color.LightCoral;
            this.tBanHang.Controls.Add(this.textBox8);
            this.tBanHang.Controls.Add(this.button4);
            this.tBanHang.Controls.Add(this.button5);
            this.tBanHang.Controls.Add(this.button6);
            this.tBanHang.Controls.Add(this.button7);
            this.tBanHang.Controls.Add(this.label22);
            this.tBanHang.Controls.Add(this.groupBox6);
            this.tBanHang.Controls.Add(this.button1);
            this.tBanHang.Controls.Add(this.button2);
            this.tBanHang.Controls.Add(this.button3);
            this.tBanHang.Controls.Add(this.groupBox5);
            this.tBanHang.Controls.Add(this.groupBox4);
            this.tBanHang.Location = new System.Drawing.Point(4, 25);
            this.tBanHang.Name = "tBanHang";
            this.tBanHang.Padding = new System.Windows.Forms.Padding(3);
            this.tBanHang.Size = new System.Drawing.Size(1134, 544);
            this.tBanHang.TabIndex = 1;
            this.tBanHang.Text = "Bán Hàng";
            this.tBanHang.Click += new System.EventHandler(this.tBanHang_Click_1);
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.Info;
            this.textBox8.Location = new System.Drawing.Point(147, 482);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(396, 41);
            this.textBox8.TabIndex = 9;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.MistyRose;
            this.button4.Location = new System.Drawing.Point(983, 479);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(127, 51);
            this.button4.TabIndex = 10;
            this.button4.Text = "Thoát";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.MistyRose;
            this.button5.Location = new System.Drawing.Point(843, 481);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(127, 51);
            this.button5.TabIndex = 11;
            this.button5.Text = "Hủy";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.MistyRose;
            this.button6.Location = new System.Drawing.Point(702, 479);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(127, 51);
            this.button6.TabIndex = 12;
            this.button6.Text = "Tìm kiếm";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.MistyRose;
            this.button7.Location = new System.Drawing.Point(569, 479);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(127, 51);
            this.button7.TabIndex = 13;
            this.button7.Text = "Lưu";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(59, 496);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(66, 16);
            this.label22.TabIndex = 8;
            this.label22.Text = "Tổng tiền:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.dataGridView1);
            this.groupBox6.Location = new System.Drawing.Point(0, 253);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1122, 206);
            this.groupBox6.TabIndex = 7;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Danh sách hàng hóa";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1116, 185);
            this.dataGridView1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MistyRose;
            this.button1.Location = new System.Drawing.Point(801, 196);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 51);
            this.button1.TabIndex = 4;
            this.button1.Text = "Sửa";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MistyRose;
            this.button2.Location = new System.Drawing.Point(990, 196);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(127, 51);
            this.button2.TabIndex = 5;
            this.button2.Text = "Xóa";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.MistyRose;
            this.button3.Location = new System.Drawing.Point(593, 196);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(127, 51);
            this.button3.TabIndex = 6;
            this.button3.Text = "Thêm";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Snow;
            this.groupBox5.Controls.Add(this.txtTTB);
            this.groupBox5.Controls.Add(this.txtGG);
            this.groupBox5.Controls.Add(this.nudSLB);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.txtDGB);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.textBox6);
            this.groupBox5.Controls.Add(this.txtMaTVB);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Location = new System.Drawing.Point(584, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(539, 184);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Thông tin hàng hóa:";
            // 
            // txtTTB
            // 
            this.txtTTB.BackColor = System.Drawing.SystemColors.Info;
            this.txtTTB.Location = new System.Drawing.Point(365, 125);
            this.txtTTB.Multiline = true;
            this.txtTTB.Name = "txtTTB";
            this.txtTTB.Size = new System.Drawing.Size(168, 37);
            this.txtTTB.TabIndex = 4;
            // 
            // txtGG
            // 
            this.txtGG.BackColor = System.Drawing.SystemColors.Info;
            this.txtGG.Location = new System.Drawing.Point(365, 24);
            this.txtGG.Multiline = true;
            this.txtGG.Name = "txtGG";
            this.txtGG.Size = new System.Drawing.Size(168, 37);
            this.txtGG.TabIndex = 3;
            // 
            // nudSLB
            // 
            this.nudSLB.BackColor = System.Drawing.SystemColors.Info;
            this.nudSLB.Location = new System.Drawing.Point(113, 86);
            this.nudSLB.Name = "nudSLB";
            this.nudSLB.Size = new System.Drawing.Size(154, 22);
            this.nudSLB.TabIndex = 2;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(280, 146);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 16);
            this.label16.TabIndex = 0;
            this.label16.Text = "Thành tiền:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(280, 30);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 16);
            this.label17.TabIndex = 0;
            this.label17.Text = "Giảm giá:";
            // 
            // txtDGB
            // 
            this.txtDGB.AutoSize = true;
            this.txtDGB.Location = new System.Drawing.Point(22, 147);
            this.txtDGB.Name = "txtDGB";
            this.txtDGB.Size = new System.Drawing.Size(56, 16);
            this.txtDGB.TabIndex = 0;
            this.txtDGB.Text = "Đơn giá:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(15, 30);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 16);
            this.label19.TabIndex = 0;
            this.label19.Text = "Mã Tivi:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(15, 86);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(63, 16);
            this.label20.TabIndex = 0;
            this.label20.Text = "Số lượng:";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.Info;
            this.textBox6.Location = new System.Drawing.Point(99, 132);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(168, 37);
            this.textBox6.TabIndex = 1;
            // 
            // txtMaTVB
            // 
            this.txtMaTVB.BackColor = System.Drawing.SystemColors.Info;
            this.txtMaTVB.Location = new System.Drawing.Point(99, 24);
            this.txtMaTVB.Multiline = true;
            this.txtMaTVB.Name = "txtMaTVB";
            this.txtMaTVB.Size = new System.Drawing.Size(168, 37);
            this.txtMaTVB.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 21);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(0, 16);
            this.label21.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Snow;
            this.groupBox4.Controls.Add(this.txtNgayBan);
            this.groupBox4.Controls.Add(this.txtMaNVB);
            this.groupBox4.Controls.Add(this.txtSoHDB);
            this.groupBox4.Controls.Add(this.txtMaKH);
            this.groupBox4.Controls.Add(this.txtThue);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Location = new System.Drawing.Point(8, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(575, 244);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Thông tin hóa đơn";
            // 
            // txtMaNVB
            // 
            this.txtMaNVB.BackColor = System.Drawing.SystemColors.Info;
            this.txtMaNVB.Location = new System.Drawing.Point(405, 21);
            this.txtMaNVB.Multiline = true;
            this.txtMaNVB.Name = "txtMaNVB";
            this.txtMaNVB.Size = new System.Drawing.Size(151, 40);
            this.txtMaNVB.TabIndex = 4;
            // 
            // txtSoHDB
            // 
            this.txtSoHDB.BackColor = System.Drawing.SystemColors.Info;
            this.txtSoHDB.Location = new System.Drawing.Point(116, 21);
            this.txtSoHDB.Multiline = true;
            this.txtSoHDB.Name = "txtSoHDB";
            this.txtSoHDB.Size = new System.Drawing.Size(151, 40);
            this.txtSoHDB.TabIndex = 4;
            // 
            // txtMaKH
            // 
            this.txtMaKH.BackColor = System.Drawing.SystemColors.Info;
            this.txtMaKH.Location = new System.Drawing.Point(117, 88);
            this.txtMaKH.Multiline = true;
            this.txtMaKH.Name = "txtMaKH";
            this.txtMaKH.Size = new System.Drawing.Size(151, 46);
            this.txtMaKH.TabIndex = 3;
            // 
            // txtThue
            // 
            this.txtThue.BackColor = System.Drawing.SystemColors.Info;
            this.txtThue.Location = new System.Drawing.Point(405, 89);
            this.txtThue.Multiline = true;
            this.txtThue.Name = "txtThue";
            this.txtThue.Size = new System.Drawing.Size(151, 46);
            this.txtThue.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 106);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(105, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "Mã Khách Hàng:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(113, 193);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 16);
            this.label13.TabIndex = 0;
            this.label13.Text = "Ngày bán:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(320, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 16);
            this.label14.TabIndex = 0;
            this.label14.Text = "Mã NV:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(320, 106);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 16);
            this.label23.TabIndex = 0;
            this.label23.Text = "Thuế:";
            this.label23.Click += new System.EventHandler(this.label15_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 27);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 16);
            this.label15.TabIndex = 0;
            this.label15.Text = "Số hóa bán:";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // tNhapHang
            // 
            this.tNhapHang.BackColor = System.Drawing.Color.RosyBrown;
            this.tNhapHang.Controls.Add(this.btnSua);
            this.tNhapHang.Controls.Add(this.txtTongTien);
            this.tNhapHang.Controls.Add(this.btnXoa);
            this.tNhapHang.Controls.Add(this.btnThem);
            this.tNhapHang.Controls.Add(this.btnThoat);
            this.tNhapHang.Controls.Add(this.btnHuy);
            this.tNhapHang.Controls.Add(this.btnTimKiem);
            this.tNhapHang.Controls.Add(this.btnLuu);
            this.tNhapHang.Controls.Add(this.groupBox3);
            this.tNhapHang.Controls.Add(this.groupBox2);
            this.tNhapHang.Controls.Add(this.groupBox1);
            this.tNhapHang.Controls.Add(this.label12);
            this.tNhapHang.Location = new System.Drawing.Point(4, 25);
            this.tNhapHang.Name = "tNhapHang";
            this.tNhapHang.Padding = new System.Windows.Forms.Padding(3);
            this.tNhapHang.Size = new System.Drawing.Size(1134, 544);
            this.tNhapHang.TabIndex = 0;
            this.tNhapHang.Text = "Nhập Hàng";
            this.tNhapHang.Click += new System.EventHandler(this.tBanHang_Click);
            // 
            // btnSua
            // 
            this.btnSua.BackColor = System.Drawing.Color.MistyRose;
            this.btnSua.Location = new System.Drawing.Point(806, 193);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(127, 51);
            this.btnSua.TabIndex = 3;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = false;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // txtTongTien
            // 
            this.txtTongTien.BackColor = System.Drawing.SystemColors.Info;
            this.txtTongTien.Location = new System.Drawing.Point(118, 474);
            this.txtTongTien.Multiline = true;
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Size = new System.Drawing.Size(396, 41);
            this.txtTongTien.TabIndex = 1;
            this.txtTongTien.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btnXoa
            // 
            this.btnXoa.BackColor = System.Drawing.Color.MistyRose;
            this.btnXoa.Location = new System.Drawing.Point(980, 193);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(127, 51);
            this.btnXoa.TabIndex = 3;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = false;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.MistyRose;
            this.btnThem.Location = new System.Drawing.Point(634, 193);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(127, 51);
            this.btnThem.TabIndex = 3;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.BackColor = System.Drawing.Color.MistyRose;
            this.btnThoat.Location = new System.Drawing.Point(954, 471);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(127, 51);
            this.btnThoat.TabIndex = 3;
            this.btnThoat.Text = "Thoát";
            this.btnThoat.UseVisualStyleBackColor = false;
            this.btnThoat.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.BackColor = System.Drawing.Color.MistyRose;
            this.btnHuy.Location = new System.Drawing.Point(814, 473);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(127, 51);
            this.btnHuy.TabIndex = 3;
            this.btnHuy.Text = "Hủy";
            this.btnHuy.UseVisualStyleBackColor = false;
            this.btnHuy.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.BackColor = System.Drawing.Color.MistyRose;
            this.btnTimKiem.Location = new System.Drawing.Point(673, 471);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(127, 51);
            this.btnTimKiem.TabIndex = 3;
            this.btnTimKiem.Text = "Tìm kiếm";
            this.btnTimKiem.UseVisualStyleBackColor = false;
            this.btnTimKiem.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.Color.MistyRose;
            this.btnLuu.Location = new System.Drawing.Point(540, 471);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(127, 51);
            this.btnLuu.TabIndex = 3;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvDSNhap);
            this.groupBox3.Location = new System.Drawing.Point(6, 246);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1122, 206);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh sách hàng nhập";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // dgvDSNhap
            // 
            this.dgvDSNhap.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvDSNhap.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDSNhap.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDSNhap.Location = new System.Drawing.Point(3, 18);
            this.dgvDSNhap.Name = "dgvDSNhap";
            this.dgvDSNhap.RowHeadersWidth = 51;
            this.dgvDSNhap.RowTemplate.Height = 24;
            this.dgvDSNhap.Size = new System.Drawing.Size(1116, 185);
            this.dgvDSNhap.TabIndex = 0;
            this.dgvDSNhap.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDSNhap_CellContentClick);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Snow;
            this.groupBox2.Controls.Add(this.txtThanhTien);
            this.groupBox2.Controls.Add(this.txtGiamGia);
            this.groupBox2.Controls.Add(this.nudSLN);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtDonGia);
            this.groupBox2.Controls.Add(this.txtMaTVN);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(589, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(539, 184);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin hàng nhập";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // txtThanhTien
            // 
            this.txtThanhTien.BackColor = System.Drawing.SystemColors.Info;
            this.txtThanhTien.Location = new System.Drawing.Point(365, 125);
            this.txtThanhTien.Multiline = true;
            this.txtThanhTien.Name = "txtThanhTien";
            this.txtThanhTien.Size = new System.Drawing.Size(168, 37);
            this.txtThanhTien.TabIndex = 4;
            this.txtThanhTien.TextChanged += new System.EventHandler(this.txtThanhTien_TextChanged);
            // 
            // txtGiamGia
            // 
            this.txtGiamGia.BackColor = System.Drawing.SystemColors.Info;
            this.txtGiamGia.Location = new System.Drawing.Point(365, 24);
            this.txtGiamGia.Multiline = true;
            this.txtGiamGia.Name = "txtGiamGia";
            this.txtGiamGia.Size = new System.Drawing.Size(168, 37);
            this.txtGiamGia.TabIndex = 3;
            this.txtGiamGia.TextChanged += new System.EventHandler(this.txtGiamGia_TextChanged);
            // 
            // nudSLN
            // 
            this.nudSLN.BackColor = System.Drawing.SystemColors.Info;
            this.nudSLN.Location = new System.Drawing.Point(113, 86);
            this.nudSLN.Name = "nudSLN";
            this.nudSLN.Size = new System.Drawing.Size(154, 22);
            this.nudSLN.TabIndex = 2;
            this.nudSLN.ValueChanged += new System.EventHandler(this.nudSoLuong_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(280, 146);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 16);
            this.label10.TabIndex = 0;
            this.label10.Text = "Thành tiền:";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(280, 30);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 16);
            this.label9.TabIndex = 0;
            this.label9.Text = "Giảm giá:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "Đơn giá:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Mã Tivi:";
            this.label5.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Số lượng:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtDonGia
            // 
            this.txtDonGia.BackColor = System.Drawing.SystemColors.Info;
            this.txtDonGia.Location = new System.Drawing.Point(99, 132);
            this.txtDonGia.Multiline = true;
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(168, 37);
            this.txtDonGia.TabIndex = 1;
            this.txtDonGia.TextChanged += new System.EventHandler(this.txtDonGia_TextChanged);
            // 
            // txtMaTVN
            // 
            this.txtMaTVN.BackColor = System.Drawing.SystemColors.Info;
            this.txtMaTVN.Location = new System.Drawing.Point(99, 24);
            this.txtMaTVN.Multiline = true;
            this.txtMaTVN.Name = "txtMaTVN";
            this.txtMaTVN.Size = new System.Drawing.Size(168, 37);
            this.txtMaTVN.TabIndex = 1;
            this.txtMaTVN.TextChanged += new System.EventHandler(this.txtMaTV_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 16);
            this.label6.TabIndex = 0;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Snow;
            this.groupBox1.Controls.Add(this.txtNgayNhap);
            this.groupBox1.Controls.Add(this.txtSoHDN);
            this.groupBox1.Controls.Add(this.txtMaNVN);
            this.groupBox1.Controls.Add(this.txtMaNCC);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(8, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(575, 234);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin hóa đơn nhập";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtSoHDN
            // 
            this.txtSoHDN.BackColor = System.Drawing.SystemColors.Info;
            this.txtSoHDN.Location = new System.Drawing.Point(191, 24);
            this.txtSoHDN.Multiline = true;
            this.txtSoHDN.Name = "txtSoHDN";
            this.txtSoHDN.Size = new System.Drawing.Size(360, 46);
            this.txtSoHDN.TabIndex = 4;
            this.txtSoHDN.TextChanged += new System.EventHandler(this.txtSoHDB_TextChanged);
            // 
            // txtMaNVN
            // 
            this.txtMaNVN.BackColor = System.Drawing.SystemColors.Info;
            this.txtMaNVN.Location = new System.Drawing.Point(191, 83);
            this.txtMaNVN.Multiline = true;
            this.txtMaNVN.Name = "txtMaNVN";
            this.txtMaNVN.Size = new System.Drawing.Size(360, 46);
            this.txtMaNVN.TabIndex = 3;
            this.txtMaNVN.TextChanged += new System.EventHandler(this.txtMaNV_TextChanged);
            // 
            // txtMaNCC
            // 
            this.txtMaNCC.BackColor = System.Drawing.SystemColors.Info;
            this.txtMaNCC.Location = new System.Drawing.Point(191, 182);
            this.txtMaNCC.Multiline = true;
            this.txtMaNCC.Name = "txtMaNCC";
            this.txtMaNCC.Size = new System.Drawing.Size(360, 46);
            this.txtMaNCC.TabIndex = 1;
            this.txtMaNCC.TextChanged += new System.EventHandler(this.txtMaNCC_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Mã NCC:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Ngày nhập:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã NV:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Số hóa đơn nhập:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(30, 488);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 16);
            this.label12.TabIndex = 0;
            this.label12.Text = "Tổng tiền:";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // QuanLiBanTV
            // 
            this.QuanLiBanTV.AccessibleName = "";
            this.QuanLiBanTV.Controls.Add(this.tNhapHang);
            this.QuanLiBanTV.Controls.Add(this.tBanHang);
            this.QuanLiBanTV.Controls.Add(this.tNhanVien);
            this.QuanLiBanTV.Controls.Add(this.tDSSP);
            this.QuanLiBanTV.Controls.Add(this.tDoanhThu);
            this.QuanLiBanTV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.QuanLiBanTV.Location = new System.Drawing.Point(0, 0);
            this.QuanLiBanTV.Name = "QuanLiBanTV";
            this.QuanLiBanTV.SelectedIndex = 0;
            this.QuanLiBanTV.Size = new System.Drawing.Size(1142, 573);
            this.QuanLiBanTV.TabIndex = 1;
            this.QuanLiBanTV.SelectedIndexChanged += new System.EventHandler(this.QuanLiBanTV_SelectedIndexChanged);
            // 
            // tDoanhThu
            // 
            this.tDoanhThu.Controls.Add(this.btnLuuDT);
            this.tDoanhThu.Controls.Add(this.btnThoatDT);
            this.tDoanhThu.Controls.Add(this.btnTimKiemDT);
            this.tDoanhThu.Controls.Add(this.groupBox12);
            this.tDoanhThu.Controls.Add(this.groupBox11);
            this.tDoanhThu.Location = new System.Drawing.Point(4, 25);
            this.tDoanhThu.Name = "tDoanhThu";
            this.tDoanhThu.Size = new System.Drawing.Size(1134, 544);
            this.tDoanhThu.TabIndex = 4;
            this.tDoanhThu.Text = "Doanh thu";
            this.tDoanhThu.UseVisualStyleBackColor = true;
            // 
            // btnLuuDT
            // 
            this.btnLuuDT.BackColor = System.Drawing.Color.MistyRose;
            this.btnLuuDT.Location = new System.Drawing.Point(500, 470);
            this.btnLuuDT.Name = "btnLuuDT";
            this.btnLuuDT.Size = new System.Drawing.Size(127, 51);
            this.btnLuuDT.TabIndex = 14;
            this.btnLuuDT.Text = "Lưu";
            this.btnLuuDT.UseVisualStyleBackColor = false;
            // 
            // btnThoatDT
            // 
            this.btnThoatDT.BackColor = System.Drawing.Color.MistyRose;
            this.btnThoatDT.Location = new System.Drawing.Point(999, 470);
            this.btnThoatDT.Name = "btnThoatDT";
            this.btnThoatDT.Size = new System.Drawing.Size(127, 51);
            this.btnThoatDT.TabIndex = 13;
            this.btnThoatDT.Text = "Thoát";
            this.btnThoatDT.UseVisualStyleBackColor = false;
            // 
            // btnTimKiemDT
            // 
            this.btnTimKiemDT.BackColor = System.Drawing.Color.MistyRose;
            this.btnTimKiemDT.Location = new System.Drawing.Point(747, 470);
            this.btnTimKiemDT.Name = "btnTimKiemDT";
            this.btnTimKiemDT.Size = new System.Drawing.Size(127, 51);
            this.btnTimKiemDT.TabIndex = 12;
            this.btnTimKiemDT.Text = "Tìm Kiếm";
            this.btnTimKiemDT.UseVisualStyleBackColor = false;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.dgvDoanhThu);
            this.groupBox12.Location = new System.Drawing.Point(3, 110);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(1123, 333);
            this.groupBox12.TabIndex = 1;
            this.groupBox12.TabStop = false;
            // 
            // dgvDoanhThu
            // 
            this.dgvDoanhThu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoanhThu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDoanhThu.Location = new System.Drawing.Point(3, 18);
            this.dgvDoanhThu.Name = "dgvDoanhThu";
            this.dgvDoanhThu.RowHeadersWidth = 51;
            this.dgvDoanhThu.RowTemplate.Height = 24;
            this.dgvDoanhThu.Size = new System.Drawing.Size(1117, 312);
            this.dgvDoanhThu.TabIndex = 0;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.txtTo);
            this.groupBox11.Controls.Add(this.txtFrom);
            this.groupBox11.Controls.Add(this.btnThongKe);
            this.groupBox11.Controls.Add(this.label45);
            this.groupBox11.Controls.Add(this.label44);
            this.groupBox11.Location = new System.Drawing.Point(0, 4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(1126, 100);
            this.groupBox11.TabIndex = 0;
            this.groupBox11.TabStop = false;
            this.groupBox11.Enter += new System.EventHandler(this.groupBox11_Enter);
            // 
            // btnThongKe
            // 
            this.btnThongKe.BackColor = System.Drawing.Color.MistyRose;
            this.btnThongKe.Location = new System.Drawing.Point(500, 25);
            this.btnThongKe.Name = "btnThongKe";
            this.btnThongKe.Size = new System.Drawing.Size(127, 51);
            this.btnThongKe.TabIndex = 13;
            this.btnThongKe.Text = "Thống kê";
            this.btnThongKe.UseVisualStyleBackColor = false;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(733, 40);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(34, 16);
            this.label45.TabIndex = 4;
            this.label45.Text = "Đến:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(44, 36);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(26, 16);
            this.label44.TabIndex = 3;
            this.label44.Text = "Từ:";
            // 
            // txtNgaySinh
            // 
            this.txtNgaySinh.Location = new System.Drawing.Point(135, 214);
            this.txtNgaySinh.Mask = "00/00/0000";
            this.txtNgaySinh.Name = "txtNgaySinh";
            this.txtNgaySinh.Size = new System.Drawing.Size(100, 22);
            this.txtNgaySinh.TabIndex = 2;
            this.txtNgaySinh.ValidatingType = typeof(System.DateTime);
            // 
            // txtNgayBan
            // 
            this.txtNgayBan.Location = new System.Drawing.Point(227, 193);
            this.txtNgayBan.Mask = "00/00/0000";
            this.txtNgayBan.Name = "txtNgayBan";
            this.txtNgayBan.Size = new System.Drawing.Size(237, 22);
            this.txtNgayBan.TabIndex = 5;
            this.txtNgayBan.ValidatingType = typeof(System.DateTime);
            // 
            // txtNgayNhap
            // 
            this.txtNgayNhap.Location = new System.Drawing.Point(191, 144);
            this.txtNgayNhap.Mask = "00/00/0000";
            this.txtNgayNhap.Name = "txtNgayNhap";
            this.txtNgayNhap.Size = new System.Drawing.Size(195, 22);
            this.txtNgayNhap.TabIndex = 5;
            this.txtNgayNhap.ValidatingType = typeof(System.DateTime);
            // 
            // txtFrom
            // 
            this.txtFrom.Location = new System.Drawing.Point(131, 33);
            this.txtFrom.Mask = "00/00/0000";
            this.txtFrom.Name = "txtFrom";
            this.txtFrom.Size = new System.Drawing.Size(206, 22);
            this.txtFrom.TabIndex = 14;
            this.txtFrom.ValidatingType = typeof(System.DateTime);
            // 
            // txtTo
            // 
            this.txtTo.Location = new System.Drawing.Point(807, 37);
            this.txtTo.Mask = "00/00/0000";
            this.txtTo.Name = "txtTo";
            this.txtTo.Size = new System.Drawing.Size(206, 22);
            this.txtTo.TabIndex = 14;
            this.txtTo.ValidatingType = typeof(System.DateTime);
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1142, 573);
            this.Controls.Add(this.QuanLiBanTV);
            this.Name = "Form";
            this.Text = "Admin";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tDSSP.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgDSSP)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tNhanVien.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSNV)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tBanHang.ResumeLayout(false);
            this.tBanHang.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSLB)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tNhapHang.ResumeLayout(false);
            this.tNhapHang.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDSNhap)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSLN)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.QuanLiBanTV.ResumeLayout(false);
            this.tDoanhThu.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoanhThu)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tDSSP;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TabPage tNhanVien;
        private System.Windows.Forms.Button btnHuyNV;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.Button btnTimKiemNV;
        private System.Windows.Forms.Button btnSuaNV;
        private System.Windows.Forms.Button btnLuuNV;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.DataGridView dgvDSNV;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtMaCV;
        private System.Windows.Forms.TextBox txtMaCa;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.TextBox txtGioiTinh;
        private System.Windows.Forms.TextBox txtTenNV;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TabPage tBanHang;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtTTB;
        private System.Windows.Forms.TextBox txtGG;
        private System.Windows.Forms.NumericUpDown nudSLB;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label txtDGB;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox txtMaTVB;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtMaNVB;
        private System.Windows.Forms.TextBox txtSoHDB;
        private System.Windows.Forms.TextBox txtMaKH;
        private System.Windows.Forms.TextBox txtThue;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tNhapHang;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvDSNhap;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtThanhTien;
        private System.Windows.Forms.TextBox txtGiamGia;
        private System.Windows.Forms.NumericUpDown nudSLN;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.TextBox txtMaTVN;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtSoHDN;
        private System.Windows.Forms.TextBox txtMaNVN;
        private System.Windows.Forms.TextBox txtMaNCC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabControl QuanLiBanTV;
        private System.Windows.Forms.Button btnLuuSP;
        private System.Windows.Forms.Button btnXoaSP;
        private System.Windows.Forms.Button btnHuySP;
        private System.Windows.Forms.Button btnSuaSP;
        private System.Windows.Forms.Button btnTimKiemSP;
        private System.Windows.Forms.Button btnThemSP;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtTGBH;
        private System.Windows.Forms.TextBox txtDonGiaBan;
        private System.Windows.Forms.TextBox txtDonGiaNhap;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.TextBox txtMaNuocSX;
        private System.Windows.Forms.TextBox txtMaCo;
        private System.Windows.Forms.TextBox txtMaManHinh;
        private System.Windows.Forms.TextBox txtMaMau;
        private System.Windows.Forms.TextBox txtMaKieu;
        private System.Windows.Forms.TextBox txtMaHSX;
        private System.Windows.Forms.TextBox txtTenTV;
        private System.Windows.Forms.TextBox txtMaTV;
        private System.Windows.Forms.DataGridView dtgDSSP;
        private System.Windows.Forms.Button btnThoatNV;
        private System.Windows.Forms.Button btnThoatSP;
        private System.Windows.Forms.TabPage tDoanhThu;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.DataGridView dgvDoanhThu;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button btnTimKiemDT;
        private System.Windows.Forms.Button btnLuuDT;
        private System.Windows.Forms.Button btnThoatDT;
        private System.Windows.Forms.Button btnThongKe;
        private System.Windows.Forms.MaskedTextBox txtNgaySinh;
        private System.Windows.Forms.MaskedTextBox txtNgayBan;
        private System.Windows.Forms.MaskedTextBox txtNgayNhap;
        private System.Windows.Forms.MaskedTextBox txtTo;
        private System.Windows.Forms.MaskedTextBox txtFrom;
    }
}

